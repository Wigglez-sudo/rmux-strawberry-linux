#define UTS_MACHINE		"x86_64"
#define LINUX_COMPILE_BY	"runner"
#define LINUX_COMPILE_HOST	"runnervmgx7h7"
#define LINUX_COMPILER		"Ubuntu clang version 18.1.3 (1ubuntu1), Ubuntu LLD 18.1.3"
