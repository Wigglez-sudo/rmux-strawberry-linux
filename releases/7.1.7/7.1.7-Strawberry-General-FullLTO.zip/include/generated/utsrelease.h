#define UTS_RELEASE "7.1.7-Strawberry-General-FullLTO+"
