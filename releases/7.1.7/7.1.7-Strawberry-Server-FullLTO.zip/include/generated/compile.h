#define UTS_MACHINE		"x86_64"
#define LINUX_COMPILE_BY	"runner"
#define LINUX_COMPILE_HOST	"runnervm76f27"
#define LINUX_COMPILER		"Ubuntu clang version 18.1.3 (1ubuntu1), Ubuntu LLD 18.1.3"
